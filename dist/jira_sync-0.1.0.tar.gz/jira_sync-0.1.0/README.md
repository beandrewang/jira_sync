# Jira Sync

跨 Jira 实例的评论同步工具。支持在两个 Jira Cloud 项目之间，基于关键词筛选评论并同步。

## 快速开始

```bash
# 配置我方 Jira 连接
python jira-sync.py configure \
    --name my \
    --url https://my-company.atlassian.net \
    --email your@email.com \
    --api-token YOUR_API_TOKEN

# 配置客户方 Jira 连接
python jira-sync.py configure \
    --name customer \
    --url https://customer.atlassian.net \
    --email your@email.com \
    --api-token YOUR_API_TOKEN

# 执行同步
python jira-sync.py sync
```

## 安装

不需要安装。依赖 `click` 和 `requests`，Python 3 环境一般已预装。

```bash
# 如缺少依赖
pip install click requests
```

## 使用指南

### 配置连接

```bash
python jira-sync.py configure --name <名称> --url <URL> --email <邮箱> --api-token <Token>
```

配置时会自动测试连接有效性。连接信息保存在 `~/.jira-sync/config.json`。

| 参数 | 说明 |
|------|------|
| `--name` | 连接名称，如 `my` / `customer` |
| `--url`  | Jira 基础 URL，如 `https://xxx.atlassian.net` |
| `--email` | Jira 账号邮箱 |
| `--api-token` | [Jira API Token](https://id.atlassian.com/manage/api-tokens) |

### 查看连接

```bash
python jira-sync.py list
```

### 删除连接

```bash
python jira-sync.py delete --name <名称>
```

### 同步评论

```bash
# 交互式同步（推荐）
python jira-sync.py sync

# 先预览不同步
python jira-sync.py sync --dry-run
```

同步流程：

1. 选择 **Source Jira**（评论来源）
2. 选择 **Target Jira**（评论目标）
3. 输入 **Source Issue Key**（如 `PROJ-123`）
4. 输入 **Target Issue Key**（如 `CUST-456`）
5. 输入 **关键词**（逗号分隔，留空同步全部）
6. 确认后执行

### 关键词过滤

- 大小写不敏感
- 多个关键词用逗号分隔，任一匹配即可
- 示例：`login, payment, urgent` 匹配包含任一关键词的评论

## 功能特性

- **零额外依赖**: 仅用 `click` + `requests`
- **Jira Cloud REST API v3**: 使用 Basic Auth + API Token
- **ADF 文本提取**: 正确解析 Atlassian Document Format 中的纯文本
- **自动去重**: 基于内容指纹，避免重复推送
- **Dry-run 模式**: 先预览再执行
- **来源标记**: 同步的评论自动标注来源 Jira 名称、原始作者和时间

## 项目结构

```
jira_sync/
├── jira-sync.py         # 入口脚本
└── jira_sync/
    ├── config.py         # 连接配置管理
    ├── client.py         # Jira REST API 客户端
    ├── syncer.py         # 同步核心逻辑
    └── sync.py           # CLI 命令定义
```
